<?
/*function loadsec_que($lstname, $firstvalue=-1, $firstoption="Select Security Question", $selectedvalue=-1, $disable=false, $jsevent="", $style=""){
    $strSQL = "SELECT id, question FROM  securityquestions ORDER BY question";
    populatelist ($lstname, $strSQL, $firstvalue, $firstoption, $selectedvalue, $disable, $jsevent, $style);
} */
?>

