<table class="tbl_border" align="center" style="text-align: left; "
 border="0" cellpadding="0" cellspacing="0">
  <tbody>
    <tr class="page_caption">
      <td class="page_caption">&nbsp;&nbsp; </td>
    </tr> 
    <tr class="page_caption">
      <td class="page_caption">&nbsp;&nbsp;<?= $conf_page_caption?> </td>
    </tr>  
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td  align="center"><?= $error ?></td>
    </tr>

    <tr>
      <td>&nbsp;</td>
    </tr>
  </tbody>
  </table>

