Structure of GreenFW
--------------------------------
 greenFW/css		// css files for framework
 greenFW/files		// Misc files for framework
 greenFW/images		// images files for framework

 greenFW/include
		/class
			--class_page.php 	// new Class for Page
		/conf
			-conf.php			// configuration for project, each page etc.

		/connection
			-connection.php			// connection for project



 greenFW/js		// javascripts for project

 greenFW/layouts
		-default.html	//  Html design for project

 greenFW/template.php		// sample page .... please check
