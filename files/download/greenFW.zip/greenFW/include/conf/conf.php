<?php

//User Types
define("USERTYPE_ADMIN", 1);
define("USERTYPE_REGISTERED_USER", 2);
define("USERTYPE_EMPLOYEE", 3);

//User Status
define("USERSTATUS_ACTIVE", 1);
define("USERSTATUS_TO_BE_ACTIVATED", 2);
define("USERSTATUS_CANCELED", 3);
define("USERSTATUS_ADMIN_CANCELED", 4);



?>