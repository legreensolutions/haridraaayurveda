<?php
$tmp_index_content = 'Hi <br/><br/>

This is <A href="http://www.legreensolutions.com" target="_blank">LegreenSolutions</A> first attempt to create small FrameWork called <strong>"Green FrameWork"</strong>. This is not a complete frame work like CAKE PHP, CI, etc... Here we try to seperate presentation layer from coding, make programers and designers work easier. Also we try to create a system which help the administrator of the system can edit the static text, messages (both info and error) online. No need to edit the code !!!. <strong>"Green FrameWork"</strong> also support multy language (for static text and messages only)<br/>

This project is under testing. We would like to invite your suggetion to make this effort successfull.<br/><br/>


<strong>Other Products used:</strong><br/> <br/>

1)&nbsp;<A href="http://gurtom.com/products/menus/js" target="_blank">Gurt JavaScript Menu</A><br/>
2)&nbsp;<A href="http://tinymce.moxiecode.com" target="_blank">TinyMCE Javascript Content Editor</A><br/><br/><br/>

Regards,<br/>
Team LegreenSolutions.
';

$index_content = $this->gsconf->get_conf(CONF_TYPE_TEXT,'index_content','index',$tmp_index_content);

?>