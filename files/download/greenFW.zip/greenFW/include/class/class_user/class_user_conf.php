<?php

define("USER_DIR","images/user/");

?>