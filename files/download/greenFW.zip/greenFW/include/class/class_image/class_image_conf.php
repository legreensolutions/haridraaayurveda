<?php

define("IMAGE_DIR","images/gallery/");

?>